import React, { Component } from "react";
 
class Testimonials extends Component {
  render() {
    return (
      <div>
        <h2>Testimonials</h2>
        <p>Hear from our previous Customers!</p>

      </div>
    );
  }
}
 
export default Testimonials;