import React, { Component } from "react";
 
class Ourwork extends Component {
  render() {
    return (
      <div>
        <h2>Check Back Soon!</h2>
        <ol>
          <li>Collision Repair</li>
          <li>Paint Color Matching</li>
          <li>Bodywork & Alignment</li>
        </ol>
        <p>Photos Coming Soon!</p>
      </div>
    );
  }
}
 
export default Ourwork;