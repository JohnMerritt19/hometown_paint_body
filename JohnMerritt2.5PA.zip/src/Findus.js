import React, { Component } from "react";
 
class Findus extends Component {
  render() {
    return (
      <div>
        <h2>Find Us!</h2>
       <p>
          <a href="https://www.google.com/maps/place/Home+Town+Paint+%26+Body+LLC/data=!4m7!3m6!1s0x88fe8c2cf6abb5df:0xa45076087f843330!8m2!3d32.9710654!4d-80.210995!16s%2Fg%2F1tfc2wrg!19sChIJ37Wr9iyM_ogRMDOEfwh2UKQ?authuser=0&hl=en&rclk=1">
            <img src='hometown-map.jpg' alt="Image of map"></img>
            </a>
       
        </p>
      </div>
    );
  }
}
 
export default Findus;