import React, { Component } from "react";
 
class Contact extends Component {
  render() {
    return (
      <div>
        <h2>GOT QUESTIONS?</h2>
        <p>The easiest thing to do is Call or Email us!</p>
        <p>Call : +1(123)456-7890</p>
        <p>Email : Owner@hometownpnb.com</p>
      </div>
    );
  }
}
 
export default Contact;